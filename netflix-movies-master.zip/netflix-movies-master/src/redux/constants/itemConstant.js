export const SET_MOVIE = 'SET_MOVIE';
export const GET_GENRES = 'GET_GENRE';
